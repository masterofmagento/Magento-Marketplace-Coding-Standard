var config = {
    map: {
        '*': {
            customAdmin: 'Cirklestudio_Customproduct/js/jscolor'
        }
    },
    deps: ["jquery"]
};

