<?php
namespace Cirklestudio\Customproduct\Plugin\CheckoutCart;
class Image
{
    public function afterGetImage($item, $result)
    {
        $options = $item->getProduct()->getTypeInstance(true)->getOrderOptions($item->getProduct());
        if (@$options['info_buyRequest']['svg_data']) {
            $result->setImageUrl( $options['info_buyRequest']['svg_data'] );
        }
        return $result;
    }
}
