<?php

namespace Cirklestudio\Customproduct\Plugin\Minicart;

class Image
 {
    public function aroundGetItemData($subject, $proceed, $item){
      $result = $proceed($item);
      $options = $item->getProduct()->getTypeInstance(true)->getOrderOptions($item->getProduct());
      if (@$options['info_buyRequest']['svg_data']) {
        $result['product_image']['src'] = $options['info_buyRequest']['svg_data'];    
      }
      return $result;
   }
 }

