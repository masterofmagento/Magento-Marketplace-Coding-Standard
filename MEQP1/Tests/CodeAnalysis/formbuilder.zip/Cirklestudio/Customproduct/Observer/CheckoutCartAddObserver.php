<?php

namespace Cirklestudio\Customproduct\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
 
class CheckoutCartAddObserver implements ObserverInterface
{
    protected $_layout;
    protected $_storeManager;
    protected $_request;
    protected $_checkoutSession;
    protected $quoteFactory;
    
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\View\LayoutInterface $layout,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Checkout\Model\Session $_checkoutSession,
        \Magento\Quote\Model\QuoteFactory $quoteFactory
    ) {
        $this->_layout = $layout;
        $this->_storeManager = $storeManager;
        $this->_request = $request;
        $this->_checkoutSession = $_checkoutSession;
        $this->quoteFactory = $quoteFactory;
    }
    
    public function execute(EventObserver $observer)
    {

        $postdata = $this->_request->getPost();
        $priceoption = $postdata['custom_product'];
        $item = $observer->getQuoteItem();

        $additionalOptions = [];
        if ($additionalOption = $item->getOptionByCode('additional_options')) {
            $additionalOptions = (array) json_decode($additionalOption->getValue());
        }
              
        $item = ($item->getParentItem() ? $item->getParentItem() : $item );
        $price = $priceoption; //set your price here
        $item->setCustomPrice($price);
        $item->setOriginalCustomPrice($price);
        $item->getProduct()->setIsSuperMode(true);

        $data =  $this->_request->getPostValue();
        print_r($data);
        foreach ($data as $key => $val) {
            $string = $key;
            if (substr($string, 0, strlen('ct-')) === 'ct-') {
                $additionalOptions[] = ['label' => $key,'value' => $val ];//Option filter
            }
        }
           
        if (count($additionalOptions) > 0) {
             $item->addOption([
              'product_id' => $item->getProductId(),
              'code' => 'additional_options',
              'value' => json_encode($additionalOptions)
             ]);
        }
        $cartData = $this->_checkoutSession->getQuote();
        $quoteId = $cartData->getId();
        $quote = $this->quoteFactory->create()->load($quoteId);
                 
        $quote->setQuoteDynamicFormData(json_encode($additionalOptions));
    }
}
