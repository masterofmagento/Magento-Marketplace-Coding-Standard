<?php
namespace Cirklestudio\Customproduct\Controller\Index;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Filesystem;
use Magento\Framework\ObjectManagerInterface;
use Magento\Framework\UrlInterface;
use Magento\Framework\App\Action\Action;

class Index extends Action
{
    protected $_filesystem;
    protected $_directoryList;
    protected $_objectManager;
    protected $_urlInterface;

    public function __construct(
        Context $context,
        Filesystem $filesystem,
        DirectoryList $directoryList,
        ObjectManagerInterface $objectmanager,
        UrlInterface $urlInterface
    ) {
        $this->_filesystem = $filesystem;
        $this->_directoryList = $directoryList;
        $this->_objectManager = $objectmanager;
        $this->_urlInterface = $urlInterface;
        return parent::__construct($context);
    }

    public function execute()
    {
        $mediaDirectory = $this->_filesystem->getDirectoryRead($this->_directoryList::MEDIA);
        $destinationPath = $mediaDirectory->getAbsolutePath('cs/svg/');
       
        $storeManager = $this->_objectManager->get('Magento\Store\Model\StoreManagerInterface');
        $currentStore = $storeManager->getStore();
        $mediaUrl = $currentStore->getBaseUrl($this->_urlInterface::URL_TYPE_MEDIA);
        // echo $mediaUrl;

        $data =  $_POST;
        function file_force_contents($filename, $data, $flags = 0)
        {
            if (!is_dir(dirname($filename))) {
                mkdir(dirname($filename).'/', 0777, true);
            }
            return file_put_contents($filename, $data, $flags);
        }
        if (@$data['data']) {
            $svgname = rand(10000, 99999);
            $path = $destinationPath.$svgname.".svg";
            $img = $data['data'];
            file_force_contents($path, $img);
            echo $mediaUrl.'cs/svg/'.$svgname.'.svg';
        }
        if (@$data['itemId']) {
            try {
                $cart = $this->_objectManager->get('\Magento\Checkout\Model\Cart');
                $items = $cart->getQuote()->getAllItems();
                foreach ($items as $item) {
                    if ($item->getId() == $data['itemId']) {
                        $options = $item->getProduct()->getTypeInstance(true)->getOrderOptions($item->getProduct());
                        $part = explode("/", $options['info_buyRequest']['svg_data']);
                        foreach ($part as $key => $value) {
                            if (strpos($value, '.svg')) {
                                $myFile = $destinationPath.$value;
                                if (file_exists($myFile)) {
                                    unlink($myFile) or die("Couldn't delete file");
                                }
                            }
                        }
                    }
                }
            } catch (Exception $e) {
                // Handle exception
            }
        }
        // $options = $item->getProduct()->getTypeInstance(true)->getOrderOptions($item->getProduct());
        // $options['info_buyRequest']['svg_data'];
    }
}
